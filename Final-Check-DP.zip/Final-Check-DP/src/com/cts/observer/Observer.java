package com.cts.observer;

public interface Observer {
	
	void setNotification();
}