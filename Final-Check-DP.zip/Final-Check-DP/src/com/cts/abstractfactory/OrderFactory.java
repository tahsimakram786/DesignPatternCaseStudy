package com.cts.abstractfactory;

public interface OrderFactory {

	public void orderFurniture();
	public void orderToys();
	public void orderElectronic();
}
